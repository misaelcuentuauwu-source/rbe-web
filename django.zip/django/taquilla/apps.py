from django.apps import AppConfig


class TaquillaConfig(AppConfig):
    name = 'taquilla'
