class Config {
  // Cambia esto según donde corras el servidor:
  // Para emulador Android en PC:
  // static const String baseUrl = 'http://10.0.2.2:8000';

  // Dispositivo físico → tu IP local ej. '192.168.1.X'
  static const String baseUrl = 'http://192.168.0.14:8000';
}
