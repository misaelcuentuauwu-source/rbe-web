import 'package:flutter/material.dart';
import '../shared/inicio_screen.dart';
import 'perfil_screen.dart';
import 'historial_screen.dart';
import '../shared/buscar_boleto_screen.dart';

class HomeNavigationScreen extends StatefulWidget {
  final Map<String, dynamic> taquillero;

  const HomeNavigationScreen({super.key, required this.taquillero});

  @override
  State<HomeNavigationScreen> createState() => _HomeNavigationScreenState();
}

class _HomeNavigationScreenState extends State<HomeNavigationScreen> {
  int _selectedIndex = 0;

  static const naranja = Color(0xFFE9713A);
  static const azul = Color(0xFF2C7FB1);

  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      InicioScreen(
        vendedorId: widget.taquillero['registro'],
        tipoUsuario: 'taquillero',
        datosUsuario: widget.taquillero,
      ),
      HistorialScreen(vendedorId: widget.taquillero['registro']),
      BuscarBoletoScreen(),
      PerfilScreen(taquillero: widget.taquillero),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF4F6F9),
      body: _pages[_selectedIndex],
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.only(left: 16, right: 16, bottom: 24),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.12),
                blurRadius: 20,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildNavItem(0, Icons.home_rounded, 'Inicio'),
                _buildNavItem(1, Icons.history_rounded, 'Historial'),
                _buildNavItem(2, Icons.search_rounded, 'Buscar'),
                _buildNavItem(3, Icons.person_rounded, 'Perfil'),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(int index, IconData icon, String label) {
    final isSelected = _selectedIndex == index;
    return GestureDetector(
      onTap: () => setState(() => _selectedIndex = index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? naranja.withOpacity(0.08) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? naranja : Colors.grey.shade400,
              size: 22,
            ),
            if (isSelected) ...[
              const SizedBox(width: 6),
              Text(
                label,
                style: const TextStyle(
                  color: naranja,
                  fontSize: 13,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
